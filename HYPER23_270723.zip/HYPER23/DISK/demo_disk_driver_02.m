function demo_disk_driver

%--------------------------------------------------------------------------
% OBJECT.
% This function runs the experiments for hyperinterpolation over the unit 
% disk.
% Several hyperinterpolants are use on possibly noisy functions.
%
% It makes the following numerical experiments:
% a) Fixed noise and several well-chosen lambda parameters (where useful).
% b) Fixed lambda and variable noise.
%
% At the end of the code 
% 1. it produces the pertinent Latex files, making the relavant table.
% 2. it plots graphics comparing sparsity and L2 errors on some hyperintp.
%    variants.
% 3. it plots J(z), H(z), as in Thm.5 of the accompanying paper. 
%--------------------------------------------------------------------------
% In "Hybrid hyperinterpolation over general regions", we consider:
%
% 1. f(x,y)=(1-x.^2-y.^2).*exp(x.*cos(y))
% 2. Maximum hyperinterpolant degree: 16 (rule: ade=32).
% 3. Reference cubature rule degree of precision: 100.
% 4. Experiment 1. Noise: a=0, sigma=0.5, lambda=[5 10 50 100].
% 5. Experiment 2. Noise: a=0, sigma=[0.05 0.1 0.4 0.8], lambda=[50].
% 6. Experiment 3. Average Lambda:
% 7. Cubature points for hyperinterpolation: 561.
% 8. Cubature points for testing L2 errors: 5151.
% 9. Total amount of hyperinterpolation coefficients: 153.
%
% a) This routine runs the experiments cited in the paper above.
% b) The process took 217 seconds on a MacBook Pro, with Apple M1 processor
% and 16 GB of RAM (stage 3 may be time consuming).
%--------------------------------------------------------------------------
% Dates:
% Written on January 1, 2023: A. Sommariva.
% Modified on April 24, 2023: A. Sommariva.
% Checked on August 27, 2023: A. Sommariva.
% Joint work with Cong-Pei An, Jia-Shu Ran.
%--------------------------------------------------------------------------
% Reference paper:
% "Hybrid hyperinterpolation over general regions" 
% Congpei An · Alvise Sommariva · Jia-Shu Ran
%--------------------------------------------------------------------------
% COPYRIGHT
%--------------------------------------------------------------------------
% Copyright (C) 2023- 
%
% Authors:
% Alvise Sommariva
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <https://www.gnu.org/licenses/>.
%--------------------------------------------------------------------------


clear;

% ............................ SETTINGS ...................................

% a) PART 1: fixed noise
kV=[5 10 50 100];
a1=0; sigma1=0.5;

% b) PART 2: fixed lambda 
kS=50; % lambda is choosen equal to the "k"-th hyp. coeff. in magnitude.
a2=0; sigma2V=[0.05 0.1 0.4 0.8]; % noise parameters

% c) PART 3: sparsity plots
kP=1:100;
a3=0; sigma3=0.5;




% ........................ main code below ................................



% .................... FIRST STAGE OF EXPERIMENTS   .......................

fprintf(2,'\n \n \n \t * <strong>Stage 1.</strong> \n \n \n ') 

tic;

AE2V=[]; betaV=[]; lambdaHIST=[];
XYW=[]; XYWR=[];

for k=kV
    % Technical note: Here we reuse the cub. rules once they are computes.
    [AEinf,AE2,beta,lambdaV,XYW,XYWR]=demo_disk(k,a1,sigma1,XYW,XYWR);
    AE2V=[AE2V AE2]; betaV=[betaV beta]; lambdaHIST=[lambdaHIST lambdaV];
end

AE2T=AE2V(1,:); BETAT=betaV(1,:); % tikhonov data storage
AE2F=AE2V(2,:); BETAF=betaV(2,:); % filtered hyp. data storage
AE2L=AE2V(3,:); BETAL=betaV(3,:); % lasso hyp. data storage
AE2H=AE2V(4,:); BETAH=betaV(4,:); % Hybrid hyp. data storage
AE2HA=AE2V(5,:); BETAHA=betaV(5,:); % Hard hyp. data storage
AE20=AE2V(6,:); BETA0=betaV(6,:); % Hyp. data storage
 

% Making Matlab tables
AE2V1=AE2V; betaV1=betaV; BETAH1=BETAH;
HypType=categorical({'tikhonov'; 'filtered'; 'lasso'; 'hybrid'; 'hard'; ...
    'hyperint.'; 'hyb.spars.'});
tablemat=[AE2V1; BETAH1];
T = table(HypType,tablemat); disp(T);

% Lambda intervals (average).
fprintf('\n \t * Lambda interval (for hyp. variants): [%1.2e,%1.2e] \n',...
    min(min(lambdaHIST(kV,:))),max(max(lambdaHIST(kV,:))));

for k=1:length(kV)
    kVL=kV(k);
    fprintf('\n \t * Lambda %1.0f column (average): %1.4e',...
    k,mean(lambdaHIST(kVL,:)));
end



% ...................... SECOND STAGE OF EXPERIMENTS  .....................


% 2. Making experiments

fprintf(2,'\n \n \n \t * <strong>Stage 2.</strong> \n ') 
fprintf(2,'\n \n \t -> Average lambda: %1.3e \n \n',...
    mean(lambdaV(kS,:)));




AE2V=[]; betaV=[];

for sigma2=sigma2V
    % fprintf('\n \t sigma: %3.5e',sigma)
    [AEinf,AE2,beta,lambdaV,XYW,XYWR]=demo_disk(kS,a2,sigma2,XYW,XYWR);
    AE2V=[AE2V abs(AE2)]; betaV=[betaV abs(beta)];
end

% 3. Making tables
AE2V2=abs(AE2V); betaV2=abs(betaV); BETAH2=betaV(4,:);
HypType=categorical({'tikhonov'; 'filtered'; 'lasso'; 'hybrid'; 'hard'; ...
    'hyperint.'; 'hyb.spars.'});
tablemat=[AE2V2; BETAH2];
T = table(HypType,tablemat); disp(T)




% ....................... PRODUCE LATEX TABLE  ............................

fprintf(2,'\n \n \t -> LaTeX table \n \n');

fileID=fopen('results_latex_unitdisk_stage1.txt','w');

strC={'Tikhonov'; 'Filtered'; 'Lasso'; 'Hybrid'; 'Hard'; 'Hyperint.'; ...
    '$\|{\mathbf{\beta}}\|_{0}$'};
for k=1:7
    strL=strC{k};

    strNUM='';

    for s=1:size(AE2V1,2)

        if k< 7
            strNUML=['$',num2str(AE2V1(k,s),'%.4f'),'$ &'];
        else
            strNUML=[ '$',num2str(BETAH1(s),'%.1f'),'$ &'];
        end

        strNUM=[strNUM strNUML];

    end


    for s=1:size(AE2V2,2)

        if k< 7
            strNUML=['$',num2str(AE2V2(k,s),'%.4f'),'$ &'];
        else
            strNUML=[ '$',num2str(BETAH2(s),'%.1f'),'$ &'];
        end

        strNUM=[strNUM strNUML];
        
    end

    if k ==7
        fprintf('\n \t'); disp('\hline');
        fprintf(fileID,'\n \t \\hline');
    end

    strNUM=[extractBefore(strNUM,length(strNUM)),'\\'];

    strdisp=['{\em{',strL,'}} &',strNUM];
    fprintf('\n \t '); disp(strdisp);

    strdispfile=replace(strdisp,'\','\\');
    fprintf(fileID,strcat('\n \t',' ',strdispfile));
end

fclose(fileID);





% ....................... THIRD STAGE OF EXPERIMENTS  .....................

fprintf(2,'\n \n \n \t * <strong>Stage 3.</strong> \n ') 

AE2P=[]; betaP=[]; JzHIST=[]; HzHIST=[];

% Making experiments.
for k=kP
    % fprintf('\n \t k: %3.0f',k)
    [AEinf,AE2,beta,lambdaV,XYW,XYWR,JzL,HzL,Wg_norm2]=demo_disk(k,...
        a3,sigma3,XYW,XYWR);
    AE2P=[AE2P AE2]; betaP=[betaP beta];
    JzHIST=[JzHIST JzL]; HzHIST=[HzHIST HzL];
end


% .................... PLOT FIGURE SPARSITY vs L2 ERROR  ..................

fprintf(2,'\n \n \t -> Plotting sparsity/L2 errors figure. \n') 

figure
subplot(1,2,1)

plot(betaP(3,:),JzHIST(3,:),'*','linewidth',1.5,'markersize',15,'color','r'), box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'),axis square,
hold on

plot(betaP(3,:),HzHIST(3,:),'+','linewidth',1.5,'markersize',15,'color','r'), box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'),axis square,
hold on

plot(betaP(4,:),JzHIST(4,:),'o','linewidth',1,'markersize',21,'color','k'), box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'),axis square,
hold on

plot(betaP(4,:),HzHIST(4,:),'s','linewidth',1,'markersize',21,'color','k'), box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'),axis square,
hold on


plot(betaP(5,:),JzHIST(5,:),'d','linewidth',1.2,'markersize',17,'color','b'), box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'),axis square,
hold on

%plot(betaP(5,:),HzHIST(5,:),'d','linewidth',2,'markersize',11,'MarkerFaceColor','b','color','b'), box on, set(gca,'fontsize',16),
plot(betaP(5,:),HzHIST(5,:),'^','linewidth',1.2,'markersize',17,'color','b'), box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'),axis square,
hold on

legend({'Lasso (J)','Lasso (H)','Hybrid (J)','Hybrid (H)','Hard thresholding (J)','Hard thresholding (H)'},'interpreter','latex','fontsize',25);

xlabel({'Sparsity $(a)$'},'interpreter','latex','fontsize',25);ylabel({'Values'},'interpreter','latex','fontsize',25);
grid on;
%set(gca,'position',[0.04 0.05 0.45 0.9])

subplot(1,2,2)



semilogy(betaP(3,:),AE2P(3,:),'r*','linewidth',1,'markersize',15),box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'), axis square,
hold on
semilogy(betaP(4,:),AE2P(4,:),'ko','linewidth',1,'markersize',21),box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'), axis square,
hold on
semilogy(betaP(5,:),AE2P(5,:),'bd','linewidth',1,'markersize',17),box on, set(gca,'fontsize',16),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'), axis square,
hold on

legend({'Lasso', 'Hybrid', 'Hard thresholding'},'interpreter','latex','fontsize',25);

xlabel({'Sparsity $(b)$'},'interpreter','latex','fontsize',25);ylabel({'$L_2$ Errors'},'interpreter','latex','fontsize',25);
grid on;
%set(gca,'position',[0.53 0.05 0.45 0.9])
