
function bnd_mat=boundary2matrix(centers,rs,angles_seq,...
    disk_sequence,arcs_sizes)

% This procedure describes the boundary of the domain via a matrix
% "bnd_mat".
% The description of the k-th arc works as follows:
% 1. bnd_mat(k,1:2) is the center of the disk containing the k-th arc;
% 2. bnd_mat(k,3) is the radius of the disk containing the k-th arc;
% 3. bnd_mat(k,4:5) are the initial and final angles of the disk so to
%    define the k-th arc.
% If bnd_mat(k,1) is NaN then bnd_mat(k+1,1) determines the arc of a new
% closed curve of the boundary.

M=size(rs,1);

T=angles_seq;

bnd_mat=[];
for ii=1:length(arcs_sizes)

    init_ii=sum(arcs_sizes(1:ii-1))+1;
    end_ii=sum(arcs_sizes(1:ii));

    for jj=init_ii:end_ii
        centerL=centers(disk_sequence(jj),:);
        rL=rs(disk_sequence(jj));
        angsL=T(jj,:);
        bnd_mat=[bnd_mat; centerL rL angsL];
    end
    bnd_mat=[bnd_mat; NaN*ones(1,5)];
end

bnd_mat=bnd_mat(1:end-1,:);

